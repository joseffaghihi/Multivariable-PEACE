# Weak instruments and estimation of mean-response PEACE

Separate numerical study for the Franklin Open major revision. The quadratic follow-up supports the manuscript IV example; the three previously published experiments are unchanged. The design and tuning grid were fixed before the simulation; all estimates, including extreme values and the zero-strength endpoint, are retained.

Main finding: the specified causal response is recovered accurately with a strong valid instrument in the cubic model. Weakening the instrument makes derivative and PEACE estimates unstable, despite unchanged causal truth, confounding and treatment distribution. Regularization controls extreme estimates but can remove real curvature. This is a limitation of finite-sample IV response recovery, not a numerical integration error or a violation of exclusion.

## 1. Exact setting and causal target

\[
W,U,R,E\overset{\mathrm{ind}}\sim N(0,1),\quad X=\rho W+\tfrac12U+\sqrt{\tfrac34-\rho^2}R,\quad Y=h(X)+U+\tfrac12E,
\]

\[
g_{\mathrm{in}}(x)=\mathbb E[Y_x]=h(x)=0.4x^3+0.5x^2-0.2x-0.5,\qquad h'(x)=1.2x^2+x-0.2.
\]

Only W, X and Y are observed; U is hidden. W changes treatment but has no direct effect on outcome. Interventions on X replace its treatment equation in this specified SCM. E[Y−h(X)|W]=0 holds at all strengths, while E[Y−h(X)|X=x]=0.5x. X is always standard normal and Cov(X,U)=0.5. In fact the entire law of (X,Y) is unchanged across strengths. The target is the population total mean response; there are no covariates or mediators, so r is absent.

\[
P_d=\frac{\int_{-2.5}^{2.5}|h'(x)|\exp(-dx^2)\,\mathrm dx}{\int_{-2.5}^{2.5}\exp(-dx^2)\,\mathrm dx}.
\]

This uses the observational N(0,1) treatment law restricted and normalized on the declared evaluation window. Its normalization constant cancels in Mean PEACE. All observed treatments, including those outside the evaluation window, enter IV fitting. The unnormalized PEACE and the normalizers are also saved in targets.csv and nonlinear_estimates.csv.

| d | True Mean PEACE | Population ordinary-regression target |
| --- | --- | --- |
| 0.0 | 2.427037 | 2.8 |
| 0.25 | 1.614223 | 1.931159 |
| 0.5 | 1.122336 | 1.393508 |
| 1.0 | 0.685225 | 0.896731 |
| 2.0 | 0.442092 | 0.599996 |

The derivative is negative on (−1,1/6) and positive outside. PEACE uses its magnitude, so a larger number means greater weighted local movement, not necessarily a beneficial treatment. The true degree curve decreases over the declared grid: increasing d gives more weight to central, higher-density treatment values. The paper's covariance identity specializes to ∂P_d/∂d = −Cov_wd(|h′(X)|,X²). This describes how the weighting changes the causal movement summary; it does not claim a negative signed effect or universal monotonicity.

![The unchanged causal and observational responses, their derivatives, and attenuation of response components by the instrument.](figures/01_mechanism_and_information.png)

The unchanged causal and observational responses, their derivatives, and attenuation of response components by the instrument.

## 2. Identification and what the estimators know

For normalized Hermite polynomials H_k, E[H_k(X)|W]=ρ^k H_k(W). At every positive ρ, completeness holds in the Gaussian L² response class, hence in the finite classes fitted here. At ρ=0 it fails: the conditional moments do not distinguish centered response curves. Zero is an unidentified reference case, marked † in the plots, not another weak-but-identified scenario.

The main estimator learns a cubic response with empirical series 2SLS, using cubic functions of W as instruments for cubic functions of X. It receives only (W,X,Y), not the true response coefficients, true ρ, U, or a population first-stage operator. A quintic response/instrument class checks additional flexibility. Both classes contain the true curve, but this remains a model-conditional polynomial benchmark rather than unrestricted nonparametric estimation.

Comparators are cubic ordinary regression; unregularized cubic IV; cubic ridge IV with fixed λ=10⁻⁶, 10⁻⁴ and 10⁻²; and unregularized/regularized quintic IV. The primary ridge value 10⁻⁴ was fixed before the run. No penalty is chosen using true PEACE or favorable results. There are 500 nonlinear repetitions for each of 18 n/strength cells (9,000 datasets), yielding 63,000 fitted responses and 315,000 degree-specific estimates. Sample sizes are 1,000, 4,000 and 16,000; strengths are 0.8, 0.5, 0.2, 0.1, 0.05 and 0. The datasets are paired across strengths and nested across n; repetitions within a cell are independent.

## 3. Actual PEACE estimates, not just error scores

| ρ | Method | Mean | Median | 5th–95th percentiles | Bias | Finite-run RMSE |
| --- | --- | --- | --- | --- | --- | --- |
| 0.8 | Cubic IV | 1.1199 | 1.1204 | 1.0755–1.1623 | -0.0024 | 0.0275 |
| 0.8 | Ordinary regression | 1.3930 | 1.3919 | 1.3685–1.4219 | +0.2707 | 0.2712 |
| 0.8 | Cubic ridge IV | 1.1195 | 1.1200 | 1.0752–1.1621 | -0.0028 | 0.0276 |
| 0.5 | Cubic IV | 1.1219 | 1.1154 | 0.9577–1.3117 | -0.0005 | 0.1112 |
| 0.5 | Ordinary regression | 1.3934 | 1.3934 | 1.3672–1.4219 | +0.2711 | 0.2716 |
| 0.5 | Cubic ridge IV | 1.1157 | 1.1099 | 0.9550–1.2998 | -0.0066 | 0.1088 |
| 0.2 | Cubic IV | 5.3601 | 1.9476 | 0.9633–17.1338 | +4.2377 | 14.1323 |
| 0.2 | Ordinary regression | 1.3934 | 1.3932 | 1.3652–1.4207 | +0.2711 | 0.2716 |
| 0.2 | Cubic ridge IV | 1.2916 | 1.1913 | 0.8451–2.1387 | +0.1692 | 0.4345 |
| 0.1 | Cubic IV | 6.5243 | 2.2690 | 0.9760–27.0161 | +5.4019 | 17.3145 |
| 0.1 | Ordinary regression | 1.3934 | 1.3932 | 1.3654–1.4201 | +0.2710 | 0.2716 |
| 0.1 | Cubic ridge IV | 1.3012 | 1.2376 | 0.7383–2.0162 | +0.1789 | 0.4548 |
| 0.05 | Cubic IV | 7.4747 | 2.4180 | 1.0357–22.8720 | +6.3524 | 25.2277 |
| 0.05 | Ordinary regression | 1.3933 | 1.3932 | 1.3660–1.4202 | +0.2710 | 0.2715 |
| 0.05 | Cubic ridge IV | 1.3244 | 1.2707 | 0.6692–2.1784 | +0.2021 | 0.5055 |
| 0† | Cubic IV | 8.5954 | 2.7498 | 1.0728–25.1093 | +7.4730 | 35.2240 |
| 0† | Ordinary regression | 1.3933 | 1.3931 | 1.3663–1.4200 | +0.2710 | 0.2715 |
| 0† | Cubic ridge IV | 1.3624 | 1.3469 | 0.5499–2.1927 | +0.2401 | 0.5752 |

The true value in every row is 1.12233598. The ranges summarize estimates across 500 independently generated datasets; they are not confidence intervals for a single dataset. All means, SDs, biases, RMSEs and conventional plug-in Monte Carlo error diagnostics are available in nonlinear_summary.csv. Just-identified IV estimates can have extremely heavy tails and nonexistent population moments: the displayed mean/bias/RMSE describe this finite run, not guaranteed population moments. Their plug-in mean_mcse and rmse_mcse therefore do not supply justified confidence bounds for population averages in those cases. Medians and percentiles are necessary for judging performance.

At ρ=0.8, cubic IV has median 1.1204, 5th–95th percentiles 1.0755–1.1623 and finite-run RMSE 0.0275. All 500 estimates are within 10% of truth. Ordinary regression is very concentrated around the wrong target (about 1.3935) and none is within 10%. Precision of an observational regression does not eliminate causal confounding bias.

At ρ=0.2, cubic IV has median 1.9476 and 5th–95th percentiles 0.9633–17.1338; only 13.2% are within 10% of truth. The primary ridge estimate has median 1.1913 and a narrower range 0.8451–2.1387, yet only 29.4% are within 10%. Its apparently closer median is not reliable recovery of the causal curve. At still weaker instruments the instability persists. Values at zero strength have no point-identification interpretation.

![Actual Mean PEACE distributions for three sample sizes at d=1/2. Points are medians; bars are 5th–95th percentiles, not confidence intervals. Logarithmic vertical scale. The zero-strength endpoint † is unidentified. Extreme observations beyond these percentiles are retained in the raw results.](figures/02_weak_instrument_performance.png)

Actual Mean PEACE distributions for three sample sizes at d=1/2. Points are medians; bars are 5th–95th percentiles, not confidence intervals. Logarithmic vertical scale. The zero-strength endpoint † is unidentified. Extreme observations beyond these percentiles are retained in the raw results.

## 4. Response curves, sample size and strength diagnostics

For n=4,000, the median derivative L² error under the restricted natural treatment law is 0.0564 for cubic IV at ρ=0.8, compared with 1.9826 at ρ=0.2. At ρ=0.2 ridge reduces it to 1.0744, which is still substantial. A scalar PEACE estimate near truth can occur even with an inaccurate response derivative, so scalar agreement alone is insufficient. The fitted curves below use the prespecified repetition 0, not a dataset selected after inspecting results; aggregate performance is established by the repeated-simulation tables.

![Exact fitted responses and derivatives from one prespecified dataset (repetition 0, n=4,000). Vertical scales vary by panel to retain the complete fitted curves. These panels illustrate possible behavior; the repeated results quantify how often it occurs.](figures/03_actual_response_and_derivatives.png)

Exact fitted responses and derivatives from one prespecified dataset (repetition 0, n=4,000). Vertical scales vary by panel to retain the complete fitted curves. These panels illustrate possible behavior; the repeated results quantify how often it occurs.

| ρ | n | Median | 5th–95th percentiles | Within 10% of truth |
| --- | --- | --- | --- | --- |
| 0.8 | 1000 | 1.1217 | 1.0237–1.2019 | 95.8% |
| 0.8 | 4000 | 1.1204 | 1.0755–1.1623 | 100.0% |
| 0.8 | 16000 | 1.1223 | 1.1013–1.1424 | 100.0% |
| 0.5 | 1000 | 1.1747 | 0.9090–2.4009 | 43.2% |
| 0.5 | 4000 | 1.1154 | 0.9577–1.3117 | 71.8% |
| 0.5 | 16000 | 1.1214 | 1.0455–1.2041 | 98.0% |
| 0.2 | 1000 | 2.0902 | 0.9599–14.4775 | 11.6% |
| 0.2 | 4000 | 1.9476 | 0.9633–17.1338 | 13.2% |
| 0.2 | 16000 | 1.4436 | 0.9424–9.3833 | 21.0% |

More data help when instrument information is adequate. At ρ=0.5, the fraction within 10% improves from 43.2% at n=1,000 to 98.0% at n=16,000. At ρ=0.2 it improves only from 11.6% to 21.0%; the cubic direction remains poorly measured over this sample-size range. This does not mean an identified positive-strength case can never improve at a much larger n.

| ρ | Median linear first-stage F | Population cubic multiplier ρ³ | nρ⁶ (n=4,000) |
| --- | --- | --- | --- |
| 0.8 | 7119.05 | 0.512 | 1048.576 |
| 0.5 | 1332.27 | 0.125 | 62.5 |
| 0.2 | 165.8 | 0.008 | 0.256 |
| 0.1 | 39.64 | 0.001 | 0.004 |
| 0.05 | 9.6 | 0.000125 | 6.3e-05 |
| 0.0 | 0.38 | 0.0 | 0.0 |

At ρ=0.2 the median linear F is 165.8, but the population cubic multiplier is 0.008 and nρ⁶ is only 0.256. A scalar linear first-stage diagnostic is not sufficient to certify nonlinear response or derivative recovery. The component scale nρ²ᵏ is explanatory for this Gaussian series design, not a universal sample-size theorem or a proposed new weak-instrument threshold.

## 5. Penalty, response-class and degree sensitivity

At n=4,000 and ρ=0.2, cubic median Mean PEACE changes from 1.9476 without a penalty to 1.8740, 1.1913 and 0.7914 for λ=10⁻⁶, 10⁻⁴ and 10⁻². The last value is below truth. Regularization suppresses noise and real response features together; it is not an identification repair. A fixed nonzero penalty also gives population shrinkage θ_k ↦ [ρ²ᵏ/(ρ²ᵏ+λ)]θ_k, so its asymptotic target is generally biased. Population penalized limits are saved separately.

The quintic class introduces additional weak directions even though it contains the true cubic. At ρ=0.5 and n=4,000, unregularized quintic IV has median 1.5059 and a 5th–95th range 0.8837–13.3498, compared with cubic IV median 1.1154 and range 0.9577–1.3117. Thus favorable cubic results depend on the declared response-class restriction; additional flexibility is not cost free. The complete quintic results and every penalty are retained, including outcomes unfavorable to the method.

![Median estimates at n=4,000 and d=1/2 across the full prespecified penalty and response-class comparisons. The dashed line is the common causal target. Smaller visual spread or a median near truth does not establish unbiased recovery.](figures/04_penalty_and_response_class.png)

Median estimates at n=4,000 and d=1/2 across the full prespecified penalty and response-class comparisons. The dashed line is the common causal target. Smaller visual spread or a median near truth does not establish unbiased recovery.

![Degree sensitivity for the fixed grid d=0, 1/4, 1/2, 1, 2. Each degree has its own true target, shown by the dashed curve. No degree is selected using ground-truth error. There is no covariate weighting parameter r in this design.](figures/05_degree_sensitivity.png)

Degree sensitivity for the fixed grid d=0, 1/4, 1/2, 1, 2. Each degree has its own true target, shown by the dashed curve. No degree is selected using ground-truth error. There is no covariate weighting parameter r in this design.

The primary experiment deliberately uses the known marginal density to isolate response estimation. A paired check replaces it with a normal density whose mean and variance are fitted using observed X. At ρ=0.8, the cubic-IV finite-run RMSE rises from 0.0275 to 0.0356. Density uncertainty therefore matters at good response precision. At ρ=0.2 the corresponding values are 14.1323 and 14.0978: density fitting does not explain the weak-IV instability. These are finite-run tail-sensitive RMSEs, not population guarantees. The density check is correctly specified and parametric, not a general robustness result for kernel density estimation. At d=0 the fitted-density and known-density results coincide exactly by construction.

![Paired known-density and fitted-normal-density calculations on the same estimated responses. Finite-run RMSE is shown on a logarithmic scale; unregularized IV tails require the additional medians and percentiles reported above.](figures/06_density_sensitivity.png)

Paired known-density and fitted-normal-density calculations on the same estimated responses. Finite-run RMSE is shown on a logarithmic scale; unregularized IV tails require the additional medians and percentiles reported above.

## 6. What uncertainty should look like with a weak instrument

A companion linear model uses h(x)=βx, β=1, with the same treatment and disturbance equations. Mean PEACE equals |β|=1 at every d. For each cell, 5,000 independent samples are represented by exact Wishart draws of their centered Gaussian cross-products. Conventional IV Wald intervals are compared with Anderson–Rubin confidence sets obtained by inverting the exact t test of W in regression of Y−bX on (1,W). The whole coefficient set, including unbounded/disconnected sets, is mapped through absolute value for PEACE.

| ρ | Wald coefficient coverage | AR coefficient coverage | AR PEACE coverage | AR sets unbounded |
| --- | --- | --- | --- | --- |
| 0.8 | 94.74% | 94.66% | 94.66% | 0.00% |
| 0.5 | 95.32% | 95.12% | 95.12% | 0.00% |
| 0.2 | 95.70% | 95.58% | 95.98% | 0.00% |
| 0.1 | 96.16% | 94.92% | 97.36% | 11.36% |
| 0.05 | 97.02% | 94.94% | 97.54% | 63.70% |
| 0.0 | 99.06% | 95.04% | 98.24% | 95.16% |

Anderson–Rubin coefficient coverage is compatible with 95% throughout the grid; across all 18 cells its largest deviation is 1.89 Monte Carlo standard errors. Mapping to |β| can make coverage conservative because positive and negative coefficients have the same magnitude. At ρ=0.05 and n=1,000, coefficient coverage is 94.94%, PEACE coverage 97.54%, and 63.70% of the sets are unbounded. At zero strength 95.16% are unbounded. Coverage alone therefore does not mean precise or useful estimation.

In this specific design, conventional Wald coverage becomes conservative as the instrument weakens (97.02% coefficient coverage at ρ=0.05 and n=1,000, and 99.06% at zero). These results do not show Wald undercoverage and should not be described that way. Its always-finite intervals do not supply the exact weak-instrument guarantee of the inverted test. The exact inference claim here depends on the specified Gaussian independent-disturbance linear model; it is not asserted for the nonlinear regularized estimator.

![Linear inference check. Coverage error bars are ±2 Monte Carlo standard errors, not confidence intervals for causal effects. Anderson–Rubin sets can become unbounded, honestly reflecting weak information. Magnitude projection can increase coverage above 95%.](figures/07_linear_uncertainty.png)

Linear inference check. Coverage error bars are ±2 Monte Carlo standard errors, not confidence intervals for causal effects. Anderson–Rubin sets can become unbounded, honestly reflecting weak information. Magnitude projection can increase coverage above 95%.

## 7. Numerical verification and limits of the conclusion

All independent checks passed. The Hermite conditional-expectation identity was checked by Gaussian quadrature; estimator coefficients were checked using independently constructed columns and projection equations. Integration was checked for 187 fitted responses, including extreme estimates, against adaptive integration and a doubled quadrature rule. Maximum relative adaptive error was 3.5e-15. Confidence-set projections were independently checked for 5,000 stored samples and against direct-data regressions. Every finite-run bias/SD/RMSE summary was recomputed. Manuscript hashes are unchanged. See results/audit.json.

What this adds: a controlled numerical illustration of the manuscript's IV mean-response identification route, including valid-but-weak instruments, an explicitly unidentified endpoint, actual effect estimates, bias/variability, derivative recovery, regularization sensitivity and weak-IV-robust uncertainty in a linear check. It provides the missing numerical evidence requested by Reviewer 3 without claiming that PEACE is immune to weak instruments.

What it does not establish: unrestricted nonparametric performance; validity under exclusion violations or arbitrary heterogeneous structural responses; a data-driven optimal penalty or degree; confidence intervals for nonlinear regularized PEACE; a general density estimator guarantee; predictive superiority; or a covariate-degree r result. The finite polynomial response restriction, additive Gaussian construction, fixed treatment window and correctly specified density check remain explicit in the manuscript summary.

## 8. Reproduction and files

Use README.md for commands and requirements-lock.txt for the tested Python environment. DESIGN.md records the prespecified design; Mathematical_argument.md gives the equations, identification argument, estimator and confidence-set derivation. experiment.py regenerates all raw and summary data; audit.py independently checks them; report.py generates this report and seven figures in PNG/SVG formats. The sources and reference results are distributed with the GitHub reproducibility package; the quadratic follow-up supplies the manuscript IV table.

## Methodological sources

- [Newey and Powell (2003), Instrumental Variable Estimation of Nonparametric Models](https://doi.org/10.1111/1468-0262.00459)

- [Darolles, Fan, Florens and Renault (2011), Nonparametric Instrumental Regression](https://doi.org/10.3982/ECTA6539)

- [Andrews, Stock and Sun (2019), Weak Instruments in Instrumental Variables Regression: Theory and Practice](https://doi.org/10.1146/annurev-economics-080218-025643)

Series conditional-moment inversion, regularization and weak-instrument inference follow established IV principles. The Gaussian/Hermite calculations and conclusions about this particular PEACE target are explicitly derived and checked here; they are not a new general IV estimator.
