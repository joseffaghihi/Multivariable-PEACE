# From an estimated causal response to a contrast and Mean PEACE

This separate exploratory IV study investigates recovery of two related summaries of the same fitted causal mean response: a finite intervention contrast and aggregated local causal movement. It evaluates estimation accuracy for each target and their paired recovery. The quantities answer different scientific questions; their accuracy percentages do not rank competing causal metrics. The manuscript and original cubic experiment remain unchanged.

## 1. Full SEM, intervention and reference law

\[
W,U,R,E\overset{\mathrm{ind}}\sim N(0,1),\qquad X=\rho W+0.5U+\sqrt{0.75-\rho^2}R,\qquad Y=X+0.75(X^2-1)+U+0.5E,
\]

Observe W,X,Y. W is the instrument, U a hidden common cause of X,Y, R additional treatment noise, and E additional outcome noise. W→X→Y and U→X,U→Y are the relevant causal paths. Only the X equation is replaced under intervention; exogenous distributions are retained in this specified SEM. Thus h(x)=E[Y_x]=x+0.75(x²−1). The target does not condition on W; W supplies identifying moments. There are no covariates or mediators, hence no r parameter.

Across instrument strengths the marginal law X~N(0,1), Cov(X,U)=0.5 and the entire law of (X,Y) are fixed. The mean-IV restriction E[Y−h(X)|W]=0 holds; ordinary regression instead targets h(x)+0.5x. Positive ρ satisfies Gaussian completeness. At zero the conditional moment operator loses the centered response directions, so that endpoint is explicitly unidentified.

## 2. One finite contrast and aggregation of local contrasts

\[
\Delta_{0,1}=h(1)-h(0)=\int_0^1h'(x)\,\mathrm dx,\qquad P_d=\int_{-2.5}^{2.5}|h'(x)|w_d(x)\,\mathrm dx,\qquad w_d(x)=\frac{e^{-dx^2}}{\int_{-2.5}^{2.5}e^{-du^2}\,\mathrm du},
\]

At d=1/2 these are normalized natural treatment weights restricted to the declared window. All observations still enter IV fitting. The derivative is the limit of local contrasts divided by treatment increments; PEACE aggregates their magnitudes across the window. The single contrast Δ is therefore a reference summary of the same response, not the sole input from which PEACE can be reconstructed. Here Δ=1.75 and P₁/₂=1.41838949. Each estimate is checked against its own known truth.

## 3. Estimation and actual response-summary estimates

The main response class contains all quadratic polynomials with coefficients estimated from observed data. Fit OLS, empirical series IV, and ridge IV with fixed penalties 10⁻⁶,10⁻⁴,10⁻²; the primary ridge penalty is 10⁻⁴. An expanded cubic class checks modeling sensitivity. Estimators receive no true coefficients, latent variables, true ρ or population conditional operator. This is a declared finite-class benchmark rather than unrestricted response learning.

There are 500 repetitions for each of n=1,000,4,000,16,000 and six strengths 0.8,0.5,0.2,0.1,0.05,0. The additional precision check uses n=64,000,256,000 at strengths 0.2,0.1,0.05, with the same response and primary quadratic class. It was motivated after the first quadratic results; all six additional cells are retained. The original cubic study remains a more demanding sensitivity analysis. Seeds pair treatment/instrument/noise draws and nest sample sizes; datasets within a cell are independent.

| Quantity | Truth | Median | 5th–95th percentiles |
| --- | --- | --- | --- |
| Mean PEACE | 1.418389 | 1.416926 | 1.2707–1.5735 |
| Intervention contrast 0 → 1 | 1.75 | 1.750292 | 1.6236–1.8799 |

![Estimates of the two response summaries across strengths at n=4,000. Points are medians and bars are 5th–95th percentiles across datasets, not confidence intervals. PEACE uses a log vertical axis; the contrast axis is symmetric-log, linear between −1 and 1. No metric superiority is inferred. Zero strength † is unidentified; extreme estimates remain in the raw results.](figures/01_response_summaries.png)

Estimates of the two response summaries across strengths at n=4,000. Points are medians and bars are 5th–95th percentiles across datasets, not confidence intervals. PEACE uses a log vertical axis; the contrast axis is symmetric-log, linear between −1 and 1. No metric superiority is inferred. Zero strength † is unidentified; extreme estimates remain in the raw results.

## 4. When the contrast is accurate, how often is Mean PEACE accurate?

\[
A_\Delta=\{|\widehat\Delta-\Delta|\le0.1|\Delta|\},\qquad A_P=\{|\widehat P-P|\le0.1P\},\qquad\widehat{\Pr}(A_P\mid A_\Delta)=\frac{\#(A_P\cap A_\Delta)}{\#A_\Delta},
\]

| n | Contrast within 10% | Mean PEACE within 10% | Mean PEACE accurate among accurate contrasts |
| --- | --- | --- | --- |
| 1,000 | 22.2% | 22.2% | 78/111 (70.3%) |
| 4,000 | 38.0% | 29.2% | 138/190 (72.6%) |
| 16,000 | 69.6% | 52.6% | 262/348 (75.3%) |
| 64,000 | 97.4% | 87.2% | 436/487 (89.5%) |
| 256,000 | 100.0% | 99.8% | 499/500 (99.8%) |

Every row fixes ρ=0.2,d=1/2 and uses 500 paired response fits. At n=64,000, 487 contrasts meet tolerance and 436 of these also have accurate Mean PEACE:89.5%. The remaining 51 datasets have an accurate contrast but Mean PEACE outside tolerance. At n=256,000, 499 of 500 qualify for both, giving 99.8% conditional recovery. Counts expose the denominator and prevent confusion between overall and conditional accuracy.

These are descriptive Monte Carlo diagnostics with known causal truth. They are not a truth-free validation test available in observational data. Conditional accuracy is defined only when at least one contrast meets tolerance; a zero denominator is saved as missing, never as zero recovery. Wilson intervals quantify binomial Monte Carlo uncertainty conditional on the observed qualifying count.

![Left: accuracy of Mean PEACE overall and among datasets with an accurate contrast, at fixedρ=0.2. Conditional error bars are Wilson 95% intervals based on the qualifying contrast count. Right: the four paired accuracy states among all 500 datasets. Conditioning changes the evaluated subset; it is not a causal intervention.](figures/02_conditional_recovery.png)

Left: accuracy of Mean PEACE overall and among datasets with an accurate contrast, at fixedρ=0.2. Conditional error bars are Wilson 95% intervals based on the qualifying contrast count. Right: the four paired accuracy states among all 500 datasets. Conditioning changes the evaluated subset; it is not a causal intervention.

![Each point is one response fit at ρ=0.2. The dashed boundaries mark ±10% relative error for each target; the central square means both estimates are accurate. Symmetric-log axes retain all extreme observations and are linear within ±0.1. This displays joint estimation behavior rather than a ranking of metrics.](figures/03_paired_errors.png)

Each point is one response fit at ρ=0.2. The dashed boundaries mark ±10% relative error for each target; the central square means both estimates are accurate. Symmetric-log axes retain all extreme observations and are linear within ±0.1. This displays joint estimation behavior rather than a ranking of metrics.

## 5. Why an accurate finite contrast need not certify the aggregation

\[
h(x)=c+ax+b(x^2-1),\qquad\Delta=a+b,\qquad P_d=\int|a+2bx|w_d(x)\,\mathrm dx,
\]

\[
\widehat\Delta-\Delta=e_a+e_b,\qquad\widehat P-P\simeq0.50124e_a+1.22287e_b,
\]

Errors in a and b can cancel in the finite contrast while changing local slopes and their magnitudes. For example e_a=−e_b makes the contrast exact, but the first-order PEACE error is about 0.72163e_b. This is the mathematical reason that the conditional recovery frequency can be below 100%. Both targets depend on curvature, and its precision depends on instrument information. A single contrast does not generally determine the full response or its local variation.

The local sensitivity calculation was independently checked by adaptive quadrature and finite differences. At n=64,000/ρ=0.2, empirical coefficient SDs are about 0.0228 for a and 0.0761 for b. The first-order calculation predicts PEACE SD 0.0936, close to the observed 0.0930. This explains sampling behavior in this setting, not a universal variance ordering or weak-IV confidence theorem.

## 6. Visible limitations and sensitivity checks

| n | Contrast within 10% | Mean PEACE within 10% | Mean PEACE accurate among accurate contrasts |
| --- | --- | --- | --- |
| 1,000 | 12.0% | 9.0% | 23/60 (38.3%) |
| 4,000 | 16.4% | 15.8% | 47/82 (57.3%) |
| 16,000 | 11.4% | 14.6% | 40/57 (70.2%) |
| 64,000 | 17.2% | 14.4% | 60/86 (69.8%) |
| 256,000 | 22.4% | 15.8% | 72/112 (64.3%) |

Lower correlation can support good recovery when sample size provides adequate effective information, as at ρ=0.2/n=256,000. Atρ=0.05 the curvature direction remains weak even at that n: the illustrative nρ⁴ scale is 1.6, compared with 409.6 at ρ=0.2. The marginal contrast accuracy is 22.4% and Mean PEACE accuracy 15.8% there. These are design-specific component scales, not universal diagnostic thresholds. Completeness establishes uniqueness, not finite-sample precision.

![Mean PEACE recovery across sample size and instrument strength. Curves show medians; shaded bands are 5th–95th percentiles. Both axes are logarithmic. The same response and fixed penalty are used along each curve, including unsuccessful cells.](figures/04_weak_information.png)

Mean PEACE recovery across sample size and instrument strength. Curves show medians; shaded bands are 5th–95th percentiles. Both axes are logarithmic. The same response and fixed penalty are used along each curve, including unsuccessful cells.

Fixed regularization can suppress real curvature and stay biased as n grows. The expanded response class adds another weak direction even though the true extra coefficient is zero. Both are displayed. Known marginal weights isolate response error; a paired fitted-normal-density calculation remains in the numerical outputs and can matter once response estimates become precise. At d=0 density fitting has no effect on the unit weights. No general nonparametric density guarantee is asserted.

![Fixed penalty and response-class sensitivity of estimated Mean PEACE at n=4,000/d=1/2. Curves show medians; full sampling distributions and error summaries remain available. Estimation choices are evaluated for the same target.](figures/05_estimation_sensitivity.png)

Fixed penalty and response-class sensitivity of estimated Mean PEACE at n=4,000/d=1/2. Curves show medians; full sampling distributions and error summaries remain available. Estimation choices are evaluated for the same target.

The original cubic response is h_c(x)=0.4x³+0.5x²−0.2x−0.5. At n=4,000/ρ=0.2 its Mean PEACE is within 10% in 13.2% of datasets, versus 29.2% in the quadratic setting. Both known truths, all fitted coefficients and the original PEACE values are retained. The new paired-recovery files also cover this stress analysis. This is a comparison of specified estimation problems, not a claim that one causal functional is generally preferable.

## 7. Degree interpretation and scope

For the quadratic response, true Mean PEACE decreases from 2.0083 at d=0 to 1.0636 at d=2 over the declared grid. The degree-derivative identity specializes to ∂P_d/∂d=−Cov_wd(|h′(X)|,X²): higher d emphasizes central high-density treatment values. The finite 0→1 contrast stays 1.75 because its endpoints are fixed. Degrees define different local-aggregation priorities, and were not selected by ground-truth estimation error. They do not create missing IV information.

![Recovery of the Mean PEACE degree curve at n=4,000. Dashed curves are exact targets and solid curves are medians across 500 response fits. Each d defines its own aggregation target.](figures/06_degree_recovery.png)

Recovery of the Mean PEACE degree curve at n=4,000. Dashed curves are exact targets and solid curves are medians across 500 response fits. Each d defines its own aggregation target.

Suggested interpretation: the IV example studies how a learned causal response supports estimation of a finite intervention contrast and aggregated local causal movement. Mean PEACE recovery improves with sample size, while uncertainty about curvature can remain consequential even when the finite contrast is accurately estimated. The conditional recovery analysis quantifies that relationship and the full simulations retain its limits.

## 8. Reproduction and verification

Paired diagnostics cover 135,000 saved response fits in 270 cells. All four accuracy-state counts were independently checked, and marginal rates agree with the original summaries. Zero qualifying-count cases are retained as undefined conditional rates. The existing numerical audit verifies targets, coefficients, quadrature, nested samples and unchanged original PEACE values; full simulation reruns produced identical outputs. The original cubic study is checked against the hashes recorded before the follow-up; manuscript hash checks are optional when manuscript sources are present.

Run python report.py after the saved simulations exist. It rebuilds recovery.py diagnostics, checks local sensitivity, and generates this report, the compact summary and six figures. README.md documents the full reproduction commands and simulation restrictions. The sources and full reference results are distributed in the GitHub reproducibility package, and the quadratic IV results support the manuscript example.

[Compact summary](COMPACT_SUMMARY.md)

[Mathematical argument](Mathematical_argument.md)

[Original cubic study and linear robust-inference check](../REPORT.html)
